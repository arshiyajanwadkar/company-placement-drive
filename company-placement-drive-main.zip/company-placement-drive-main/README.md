# company-placement-drive
I developed a single page using HTML and CSS. The page presents relevant details about the company, such as the drive's date, eligibility criteria, job role, remuneration, probationary stipend, employment type, work location, and selection process. Additionally, I incorporated a nomination form to enable students to apply for the placement drive.
